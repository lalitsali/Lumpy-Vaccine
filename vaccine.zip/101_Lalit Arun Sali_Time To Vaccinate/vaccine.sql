-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2023 at 07:38 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vaccine`
--

-- --------------------------------------------------------

--
-- Table structure for table `addhcamp`
--

CREATE TABLE `addhcamp` (
  `id` int(11) NOT NULL,
  `usernameH` varchar(222) NOT NULL,
  `passwordH` varchar(222) NOT NULL,
  `camp` varchar(222) NOT NULL,
  `locationH` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addhcamp`
--

INSERT INTO `addhcamp` (`id`, `usernameH`, `passwordH`, `camp`, `locationH`) VALUES
(1, 'nayarhospital@123', 'n', 'army', 'nashik'),
(5, 'nayarhospital@123', 'n', 'army', 'mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(22) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `name` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `name`) VALUES
(8, 'lalit@123', 'l', 'Lalit Arun Sali');

-- --------------------------------------------------------

--
-- Table structure for table `adminhealthtips`
--

CREATE TABLE `adminhealthtips` (
  `id` int(222) NOT NULL,
  `Tips` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminhealthtips`
--

INSERT INTO `adminhealthtips` (`id`, `Tips`) VALUES
(1, 'clean area'),
(2, 'Lumpy skin disease is a viral disease that affects cattle. '),
(3, ' The disease is characterized by large fever, enlarged superficial lymph nodes and multiple nodules on the skin and mucous membranes'),
(4, 'Lumpy skin disease is a contagious viral disease that spreads among cattle through mosquitoes, flies, lice and wasps by direct contact, as also');

-- --------------------------------------------------------

--
-- Table structure for table `animal`
--

CREATE TABLE `animal` (
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `type` varchar(222) NOT NULL,
  `age` int(222) NOT NULL,
  `animal_id` int(222) NOT NULL,
  `id` int(222) NOT NULL,
  `status` varchar(222) NOT NULL DEFAULT 'pending',
  `Husername` varchar(222) NOT NULL,
  `location` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `animal`
--

INSERT INTO `animal` (`username`, `password`, `type`, `age`, `animal_id`, `id`, `status`, `Husername`, `location`) VALUES
('lalit@123', 'l', 'cow', 58, 4, 8, 'Approved', 'nayarhospital@123', 'nashik'),
('ram123', 'r', 'cow', 15, 11, 9, 'Approved', '', ''),
('ram123', 'r', 'buffelo', 3, 4, 10, 'Approved', 'nayarhospital@123', 'mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `answer` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`id`, `username`, `answer`) VALUES
(0, 'rftg', 'fr'),
(1, 'rftg', 'wsed'),
(1, 'ram123', 'you Should use goverment verified medicine for animal');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `id` int(22) NOT NULL,
  `usernameH` varchar(222) NOT NULL,
  `passwordH` varchar(222) NOT NULL,
  `camp` varchar(222) NOT NULL,
  `location` varchar(222) NOT NULL,
  `statusH` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`id`, `usernameH`, `passwordH`, `camp`, `location`, `statusH`) VALUES
(16, 'nayarhospital@123', 'n', 'army', 'nashik', 'Approved'),
(17, 'mjHospital', 'm', 'army', 'nashik', 'pending'),
(18, 'nayarhospital@123', 'n', 'zoo', 'mumbai', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `qusetion`
--

CREATE TABLE `qusetion` (
  `id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `question` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `qusetion`
--

INSERT INTO `qusetion` (`id`, `username`, `question`) VALUES
(1, 'ram123', 'which medicine is good for cow');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(222) NOT NULL,
  `usernameU` varchar(222) NOT NULL,
  `passwordU` varchar(222) NOT NULL,
  `city` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `usernameU`, `passwordU`, `city`) VALUES
(1, 'lalit@123', 'l', 'parola'),
(5, 'ram123', 'r', 'mumbai');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addhcamp`
--
ALTER TABLE `addhcamp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminhealthtips`
--
ALTER TABLE `adminhealthtips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `animal`
--
ALTER TABLE `animal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qusetion`
--
ALTER TABLE `qusetion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addhcamp`
--
ALTER TABLE `addhcamp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `adminhealthtips`
--
ALTER TABLE `adminhealthtips`
  MODIFY `id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `animal`
--
ALTER TABLE `animal`
  MODIFY `id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `qusetion`
--
ALTER TABLE `qusetion`
  MODIFY `id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
